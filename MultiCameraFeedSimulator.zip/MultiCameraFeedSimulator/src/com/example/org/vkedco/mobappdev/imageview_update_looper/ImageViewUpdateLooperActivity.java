package com.example.org.vkedco.mobappdev.imageview_update_looper;

// bugs to vladimir dot kulyukin at gmail dot com
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;

public class ImageViewUpdateLooperActivity extends Activity 
implements OnClickListener
{
	static final String CAMERA_THREAD_01 = "CameraThread01";
	static final String CAMERA_THREAD_02 = "CameraThread02";
	
	Handler mImageUpdateHandler = new Handler();
	
	int[] mCameraFeedImages01 = null;
	int[] mCameraFeedImages02 = null; 
	
	CameraFeedThread mCameraFeedThread01 = null;
	CameraFeedThread mCameraFeedThread02 = null;
	
	ImageView mCameraImage01 = null;
	ImageView mCameraImage02 = null;
	
	Button mBtnCamera01 = null;
	Button mBtnCamera02 = null;
	
	boolean mThread01Running = false;
	boolean mThread02Running = false;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_image_view_update_looper);
		
		mCameraFeedImages01 = new int[] {
				R.drawable.img_01,
				R.drawable.img_02,
				R.drawable.img_03,
				R.drawable.img_04,
				R.drawable.img_05,
				R.drawable.img_06,
				R.drawable.img_07,
				R.drawable.img_08,
				R.drawable.img_09,
				R.drawable.img_10
		};
		
		mCameraFeedImages02 = new int[] {
				R.drawable.img_11,
				R.drawable.img_12,
				R.drawable.img_13,
				R.drawable.img_14,
				R.drawable.img_15,
				R.drawable.img_16,
				R.drawable.img_17,
				R.drawable.img_18
		};
		
		mCameraImage01 = (ImageView) this.findViewById(R.id.CameraImage01);
		mCameraImage02 = (ImageView) this.findViewById(R.id.CameraImage02);
		
		mBtnCamera01 = (Button) this.findViewById(R.id.btnCamera01);
		mBtnCamera02 = (Button) this.findViewById(R.id.btnCamera02);
		
		mBtnCamera01.setOnClickListener(this);
		mBtnCamera02.setOnClickListener(this);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.image_view_update_looper, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onClick(View v) {
		switch ( v.getId() ) {
		case R.id.btnCamera01:
			if ( this.mThread01Running == false ) {
				mCameraFeedThread01 = new CameraFeedThread(this, this.mImageUpdateHandler,
						this.mCameraImage01, this.mCameraFeedImages01, 2000);
				mCameraFeedThread01.setName(CAMERA_THREAD_01);
				mCameraFeedThread01.start();
				this.mThread01Running = true;
			}
			else {
				this.mThread01Running = false;
				mCameraFeedThread01.setThreadRunning(false);
				this.mCameraFeedThread01 = null;
			}
			break;
		case R.id.btnCamera02:
			if ( this.mThread02Running == false ) {
				mCameraFeedThread02 = new CameraFeedThread(this, this.mImageUpdateHandler, 
						this.mCameraImage02, this.mCameraFeedImages02, 1000);
				mCameraFeedThread02.setName(CAMERA_THREAD_02);
				mCameraFeedThread02.start();
				this.mThread02Running = true;
			}
			else {
				this.mThread02Running = false;
				mCameraFeedThread02.setThreadRunning(false);
				mCameraFeedThread02 = null;
			}
			break;
		default: break;
		}
	}
}
