package com.example.org.vkedco.mobappdev.imageview_update_looper;

// // problem description is at http://vkedco.blogspot.com/2014/09/simulating-remote-multi-camera-feed.html
// bugs to vladimir dot kulyukin at gmail dot com
import android.content.Context;
import android.content.res.Resources;
import android.os.Handler;
import android.widget.ImageView;

public class CameraFeedThread extends Thread {

	Resources mRes = null;
	int[] mImages = null;
	int mSleepInterval = 0;
	Handler mHandler = null;
	ImageView mImageView = null;
	int mNumImages = 0;
	int mCurImage = 0;
	Context mContext = null;
	boolean mThreadRunning = true;

	public CameraFeedThread(Context cntxt, Handler handler, ImageView imgv,
			int[] images, int sleep_interval) {
		this.mRes = cntxt.getResources();
		this.mImages = images;
		this.mSleepInterval = sleep_interval;
		this.mHandler = handler;
		this.mImageView = imgv;
		this.mNumImages = images.length;
		this.mContext = cntxt;
	}

	@Override
	public void run() {
		while ( true ) {
			
			if ( !mThreadRunning ) break;
			
			mHandler.post(new Runnable() {
				@Override
				public void run() {
					mImageView.setImageDrawable(mRes
							.getDrawable(mImages[mCurImage]));
					mCurImage = (mCurImage + 1) % mNumImages;
				}
			});

			try {
				Thread.sleep(mSleepInterval);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	void setThreadRunning(boolean flag) {
		this.mThreadRunning = flag;
	}

}
