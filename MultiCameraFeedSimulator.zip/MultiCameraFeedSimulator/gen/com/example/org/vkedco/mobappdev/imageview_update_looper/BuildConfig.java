/** Automatically generated file. DO NOT MODIFY */
package com.example.org.vkedco.mobappdev.imageview_update_looper;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}